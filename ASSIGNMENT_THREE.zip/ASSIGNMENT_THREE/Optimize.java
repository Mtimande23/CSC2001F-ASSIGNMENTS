//Themba Shongwe
//SHNTHE021
//Assignment 4 - Hashing
//2025/


import java.io.*;
import java.util.*;

public class Optimize {
    public ArrayList<String> L = new ArrayList<>();
    public int bestProbeCount = Integer.MAX_VALUE; // Initialize to max value
    public int numOfOccurence = 0;
    public int[] weights = new int[9];
    public static final int weightLength = 9;
    public static final int maxWeightSize = 4;


     /**
     * Constructor for the Optimize class.
     * Reads usernames from the input file and calculates the optimal weights.
     */
    public Optimize() {
        Scanner user;
        try {
            // Read usernames from the file
            user = new Scanner(new File("mydata.txt"));
            while (user.hasNextLine()) {
                L.add(user.nextLine().trim());
            }
            user.close();

            // Generate all combinations of weights recursively
            generateCombos(weights, 0);

        } catch (FileNotFoundException e) {
            System.out.println("Error: File 'mydata.txt' not found.");
            return;
        }
            System.out.println(bestProbeCount + " " + numOfOccurence);
    }

    /**
     * Recursively generates all possible combinations of weights.
     *
     * @param weights The current combination of weights.
     * @param pos     The current position in the weights array being set.
     */
    public void generateCombos(int[] weights, int pos) {
        if (pos == weightLength) {
            int totalProbes = probing(weights);
            if (totalProbes < bestProbeCount) {
                bestProbeCount = totalProbes;
                numOfOccurence = 1;
            } else if (totalProbes == bestProbeCount) {
                numOfOccurence++;
            }
            return;
        }

        for (int i = 0; i <= maxWeightSize; i++) {
            weights[pos] = i;
            generateCombos(weights, pos + 1);
        }
    }
     /**
     * Simulates the insertion of usernames into a hash table with the given weights
     * and calculates the total number of probes required.
     *
     * @param weights The weights to use for hashing.
     * @return The total number of probes required for all usernames.
     */
    public int probing(int[] weights) {
        int tableSize = 37; // Hash table size
        String[] table = new String[tableSize];
        int totalProbes = 0;

        for (String username : L) {
            int hash = 0;
            for (int i = 0; i < Math.min(weightLength, username.length()); i++) {
                hash += weights[i] * username.charAt(i);
            }
            int index = hash % tableSize;

            int probes = 1;
            while (table[index] != null) {
                index = (index + 1) % tableSize;
                probes++;
                if (probes > tableSize) return Integer.MAX_VALUE; // Avoid infinite loops
            }

            table[index] = username;
            totalProbes += probes;
        }

        return totalProbes;
    }
    /**
     * The main method to run the Optimize program.
     *
     * @param args main method arguments (not used).
     */
    public static void main(String[] args) {
        new Optimize();
    }
}